// Global variables
let allPatients = [];
let currentPatient = null;

// Your actual MRI images from GitHub - UPDATE THESE URLs
const githubMRIImages = [
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (1).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (2).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (3).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (4).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (5).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (6).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (7).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (8).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (9).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (10).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (11).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (12).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (13).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (14).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (15).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (16).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (17).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (18).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (19).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (20).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (21).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (22).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (23).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (24).jpg',
'https://github.com/srivarsan0001/medical-images-/blob/main/enhanced_Tumor (25).jpg',

];

// Sample patient data (first 10 patients - you can add all 100)
const samplePatients = [
    {
        "PatientID": "PT1001",
        "Age": 66,
        "Sex": "Other",
        "Clinical_Description": "66-yr Other. Presents with headache, seizures, focal weakness. Imaging: diffuse infiltration with lymphadenopathy.",
        "Date_of_Diagnosis": "2024-11-29",
        "Tumor_Type": "Breast cancer",
        "ICD10_Code": "C50",
        "WBC_10_9_per_L": 8.2,
        "Hemoglobin_g_per_dL": 15.2,
        "Platelets_10_9_per_L": 231,
        "CRP_mg_per_L": 0.3,
        "ESR_mm_per_hr": 25,
        "Creatinine_mg_per_dL": 1.25,
        "ALT_U_per_L": 55.2,
        "AST_U_per_L": 21.5,
        "Imaging_Findings": "Diffuse infiltration with lymphadenopathy",
        "Treatment": "Radiation therapy",
        "Outcome": "Recovered"
    },
    {
        "PatientID": "PT1002",
        "Age": 52,
        "Sex": "Male",
        "Clinical_Description": "52-yr Male. Presents with fever, fatigue, recurrent infections. Imaging: multiple metastatic nodules on ct chest.",
        "Date_of_Diagnosis": "2021-11-27",
        "Tumor_Type": "Pancreatic cancer",
        "ICD10_Code": "C25",
        "WBC_10_9_per_L": 5.1,
        "Hemoglobin_g_per_dL": 10.9,
        "Platelets_10_9_per_L": 205,
        "CRP_mg_per_L": 4.7,
        "ESR_mm_per_hr": 21,
        "Creatinine_mg_per_dL": 1.11,
        "ALT_U_per_L": 20.9,
        "AST_U_per_L": 10.0,
        "Imaging_Findings": "Multiple metastatic nodules on CT chest",
        "Treatment": "Immunotherapy",
        "Outcome": "Recovered"
    },
    {
        "PatientID": "PT1003",
        "Age": 60,
        "Sex": "Male",
        "Clinical_Description": "60-yr Male. Presents with fever, fatigue, recurrent infections. Imaging: no focal lesion; nonspecific changes.",
        "Date_of_Diagnosis": "2023-08-18",
        "Tumor_Type": "Lung cancer",
        "ICD10_Code": "C34",
        "WBC_10_9_per_L": 3.8,
        "Hemoglobin_g_per_dL": 13.7,
        "Platelets_10_9_per_L": 157,
        "CRP_mg_per_L": 0.3,
        "ESR_mm_per_hr": 30,
        "Creatinine_mg_per_dL": 1.18,
        "ALT_U_per_L": 53.9,
        "AST_U_per_L": 37.2,
        "Imaging_Findings": "No focal lesion; nonspecific changes",
        "Treatment": "Surgery",
        "Outcome": "Stable (on treatment)"
    },
    {
        "PatientID": "PT1004",
        "Age": 51,
        "Sex": "Other",
        "Clinical_Description": "51-yr Other. Presents with fever, fatigue, recurrent infections. Imaging: hypermetabolic lesion on pet-ct.",
        "Date_of_Diagnosis": "2021-03-22",
        "Tumor_Type": "Pancreatic cancer",
        "ICD10_Code": "C25",
        "WBC_10_9_per_L": 5.9,
        "Hemoglobin_g_per_dL": 14.0,
        "Platelets_10_9_per_L": 152,
        "CRP_mg_per_L": 1.9,
        "ESR_mm_per_hr": 52,
        "Creatinine_mg_per_dL": 1.3,
        "ALT_U_per_L": 39.4,
        "AST_U_per_L": 47.9,
        "Imaging_Findings": "Hypermetabolic lesion on PET-CT",
        "Treatment": "Radiation therapy",
        "Outcome": "Stable (on treatment)"
    },
    {
        "PatientID": "PT1005",
        "Age": 58,
        "Sex": "Female",
        "Clinical_Description": "58-yr Female. Presents with weight loss, fatigue, loss of appetite. Imaging: mass lesion in organ with irregular margins.",
        "Date_of_Diagnosis": "2022-03-09",
        "Tumor_Type": "Kidney cancer",
        "ICD10_Code": "C64",
        "WBC_10_9_per_L": 4.7,
        "Hemoglobin_g_per_dL": 10.4,
        "Platelets_10_9_per_L": 213,
        "CRP_mg_per_L": 1.6,
        "ESR_mm_per_hr": 37,
        "Creatinine_mg_per_dL": 0.99,
        "ALT_U_per_L": 37.7,
        "AST_U_per_L": 42.5,
        "Imaging_Findings": "Mass lesion in organ with irregular margins",
        "Treatment": "Immunotherapy",
        "Outcome": "Stable (on treatment)"
    },
    {
        "PatientID": "PT1006",
        "Age": 72,
        "Sex": "Male",
        "Clinical_Description": "72-yr Male. Presents with abdominal pain, jaundice, weight loss. Imaging: multiple metastatic nodules on ct chest.",
        "Date_of_Diagnosis": "2022-08-23",
        "Tumor_Type": "Lung cancer",
        "ICD10_Code": "C34",
        "WBC_10_9_per_L": 5.4,
        "Hemoglobin_g_per_dL": 14.0,
        "Platelets_10_9_per_L": 328,
        "CRP_mg_per_L": 2.0,
        "ESR_mm_per_hr": 27,
        "Creatinine_mg_per_dL": 1.29,
        "ALT_U_per_L": 58.6,
        "AST_U_per_L": 15.8,
        "Imaging_Findings": "Multiple metastatic nodules on CT chest",
        "Treatment": "Surgery + Chemotherapy",
        "Outcome": "Stable (on treatment)"
    },
    {
        "PatientID": "PT1007",
        "Age": 58,
        "Sex": "Female",
        "Clinical_Description": "58-yr Female. Presents with back pain, bone pain, night sweats. Imaging: large heterogenous mass with necrosis.",
        "Date_of_Diagnosis": "2025-04-16",
        "Tumor_Type": "Bladder cancer",
        "ICD10_Code": "C67",
        "WBC_10_9_per_L": 10.0,
        "Hemoglobin_g_per_dL": 10.5,
        "Platelets_10_9_per_L": 278,
        "CRP_mg_per_L": 7.4,
        "ESR_mm_per_hr": 41,
        "Creatinine_mg_per_dL": 1.67,
        "ALT_U_per_L": 16.6,
        "AST_U_per_L": 24.8,
        "Imaging_Findings": "Large heterogenous mass with necrosis",
        "Treatment": "Surgery",
        "Outcome": "Progressive disease"
    },
    {
        "PatientID": "PT1008",
        "Age": 59,
        "Sex": "Other",
        "Clinical_Description": "59-yr Other. Presents with hematuria, flank pain, palpable mass. Imaging: multiple metastatic nodules on ct chest.",
        "Date_of_Diagnosis": "2025-06-11",
        "Tumor_Type": "Breast cancer",
        "ICD10_Code": "C50",
        "WBC_10_9_per_L": 7.2,
        "Hemoglobin_g_per_dL": 12.7,
        "Platelets_10_9_per_L": 90,
        "CRP_mg_per_L": 11.9,
        "ESR_mm_per_hr": 21,
        "Creatinine_mg_per_dL": 0.94,
        "ALT_U_per_L": 19.2,
        "AST_U_per_L": 45.4,
        "Imaging_Findings": "Multiple metastatic nodules on CT chest",
        "Treatment": "Chemoradiation",
        "Outcome": "Progressive disease"
    },
    {
        "PatientID": "PT1009",
        "Age": 48,
        "Sex": "Other",
        "Clinical_Description": "48-yr Other. Presents with abdominal pain, jaundice, weight loss. Imaging: no focal lesion; nonspecific changes.",
        "Date_of_Diagnosis": "2025-04-12",
        "Tumor_Type": "Bladder cancer",
        "ICD10_Code": "C67",
        "WBC_10_9_per_L": 7.9,
        "Hemoglobin_g_per_dL": 13.1,
        "Platelets_10_9_per_L": 207,
        "CRP_mg_per_L": 11.2,
        "ESR_mm_per_hr": 29,
        "Creatinine_mg_per_dL": 1.31,
        "ALT_U_per_L": 38.5,
        "AST_U_per_L": 26.4,
        "Imaging_Findings": "No focal lesion; nonspecific changes",
        "Treatment": "Radiation therapy",
        "Outcome": "Progressive disease"
    },
    {
        "PatientID": "PT1010",
        "Age": 69,
        "Sex": "Male",
        "Clinical_Description": "69-yr Male. Presents with headache, seizures, focal weakness. Imaging: multiple metastatic nodules on ct chest.",
        "Date_of_Diagnosis": "2024-02-21",
        "Tumor_Type": "Pancreatic cancer",
        "ICD10_Code": "C25",
        "WBC_10_9_per_L": 4.5,
        "Hemoglobin_g_per_dL": 13.9,
        "Platelets_10_9_per_L": 270,
        "CRP_mg_per_L": 0.1,
        "ESR_mm_per_hr": 2,
        "Creatinine_mg_per_dL": 1.38,
        "ALT_U_per_L": 27.1,
        "AST_U_per_L": 26.8,
        "Imaging_Findings": "Multiple metastatic nodules on CT chest",
        "Treatment": "Radiation therapy",
        "Outcome": "Progressive disease"
    }
];

// Load patient data
function loadPatientData() {
    try {
        // Try to load from JSON file first
        fetch('data/patients.json')
            .then(response => {
                if (!response.ok) throw new Error('JSON not found');
                return response.json();
            })
            .then(data => {
                allPatients = data;
                console.log('Loaded patients from JSON:', allPatients.length);
            })
            .catch(error => {
                console.log('Using sample patient data');
                allPatients = samplePatients;
            });
    } catch (error) {
        console.log('Using sample patient data due to error');
        allPatients = samplePatients;
    }
}

// Search function
function searchPatient() {
    const searchInput = document.getElementById('patientSearch').value.trim().toUpperCase();
    const patientSection = document.getElementById('patientSection');
    
    if (!searchInput) {
        showNotification('Please enter a Patient ID (e.g., PT1001, PT1002)', 'warning');
        return;
    }

    // Show loading
    showLoading(true);

    // Simulate API call delay
    setTimeout(() => {
        // Search for patient
        const patient = allPatients.find(p => 
            p.PatientID.toUpperCase() === searchInput || 
            p.PatientID.toUpperCase().includes(searchInput)
        );

        if (patient) {
            currentPatient = patient;
            displayPatientDetails(patient);
            patientSection.style.display = 'block';
            
            // Scroll to patient section
            patientSection.scrollIntoView({ behavior: 'smooth' });
            showNotification(`Patient ${patient.PatientID} loaded successfully!`, 'success');
        } else {
            showNotification('Patient not found. Please check the Patient ID and try again.', 'error');
        }
        
        showLoading(false);
    }, 1000);
}

// Display patient details
function displayPatientDetails(patient) {
    // Update patient status
    document.getElementById('patientStatus').innerHTML = `
        <span class="status-badge outcome-${getOutcomeClass(patient.Outcome)}">
            <i class="fas fa-circle"></i>
            ${patient.Outcome}
        </span>
    `;

    // Patient Information
    document.getElementById('patientInfo').innerHTML = `
        <div class="info-item">
            <strong>Patient ID:</strong> ${patient.PatientID}
        </div>
        <div class="info-item">
            <strong>Age:</strong> ${patient.Age} years
        </div>
        <div class="info-item">
            <strong>Sex:</strong> ${patient.Sex}
        </div>
        <div class="info-item">
            <strong>Diagnosis Date:</strong> ${formatDate(patient.Date_of_Diagnosis)}
        </div>
        <div class="info-item">
            <strong>Tumor Type:</strong> ${patient.Tumor_Type}
        </div>
        <div class="info-item">
            <strong>ICD-10 Code:</strong> <span class="icd-code">${patient.ICD10_Code}</span>
        </div>
    `;

    // Clinical Information
    document.getElementById('clinicalInfo').innerHTML = `
        <div class="clinical-item">
            <strong>Clinical Presentation:</strong> 
            <p>${patient.Clinical_Description}</p>
        </div>
        <div class="clinical-item">
            <strong>Imaging Findings:</strong> 
            <p>${patient.Imaging_Findings}</p>
        </div>
        <div class="clinical-item">
            <strong>Current Treatment:</strong> 
            <span class="treatment-badge">${patient.Treatment}</span>
        </div>
        <div class="clinical-item">
            <strong>Medical History:</strong> 
            <p>${generateMedicalHistory(patient)}</p>
        </div>
    `;

    // Lab Results
    document.getElementById('labResults').innerHTML = `
        <div class="lab-item">
            <strong>WBC Count:</strong> 
            <span class="lab-value ${getLabStatus('WBC', patient.WBC_10_9_per_L)}">${patient.WBC_10_9_per_L} ×10⁹/L</span>
        </div>
        <div class="lab-item">
            <strong>Hemoglobin:</strong> 
            <span class="lab-value ${getLabStatus('Hemoglobin', patient.Hemoglobin_g_per_dL)}">${patient.Hemoglobin_g_per_dL} g/dL</span>
        </div>
        <div class="lab-item">
            <strong>Platelets:</strong> 
            <span class="lab-value ${getLabStatus('Platelets', patient.Platelets_10_9_per_L)}">${patient.Platelets_10_9_per_L} ×10⁹/L</span>
        </div>
        <div class="lab-item">
            <strong>CRP Level:</strong> 
            <span class="lab-value ${getLabStatus('CRP', patient.CRP_mg_per_L)}">${patient.CRP_mg_per_L} mg/L</span>
        </div>
        <div class="lab-item">
            <strong>ESR:</strong> 
            <span class="lab-value ${getLabStatus('ESR', patient.ESR_mm_per_hr)}">${patient.ESR_mm_per_hr} mm/hr</span>
        </div>
        <div class="lab-item">
            <strong>Creatinine:</strong> 
            <span class="lab-value ${getLabStatus('Creatinine', patient.Creatinine_mg_per_dL)}">${patient.Creatinine_mg_per_dL} mg/dL</span>
        </div>
        <div class="lab-item">
            <strong>ALT:</strong> 
            <span class="lab-value ${getLabStatus('ALT', patient.ALT_U_per_L)}">${patient.ALT_U_per_L} U/L</span>
        </div>
        <div class="lab-item">
            <strong>AST:</strong> 
            <span class="lab-value ${getLabStatus('AST', patient.AST_U_per_L)}">${patient.AST_U_per_L} U/L</span>
        </div>
    `;

    // AI Analysis
    displayAIAnalysis(patient);
}

// Helper function for outcome class
function getOutcomeClass(outcome) {
    if (outcome.includes('Recovered')) return 'recovered';
    if (outcome.includes('Stable')) return 'stable';
    if (outcome.includes('Progressive')) return 'progressive';
    if (outcome.includes('Deceased')) return 'deceased';
    return 'stable';
}

// Format date
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
}

// Generate medical history
function generateMedicalHistory(patient) {
    const histories = {
        'Breast cancer': 'Previous mammogram screenings, family history assessment, genetic testing if indicated.',
        'Lung cancer': 'Smoking history, occupational exposures, previous chest imaging.',
        'Pancreatic cancer': 'Diabetes history, chronic pancreatitis, family cancer syndrome.',
        'Brain tumor': 'Neurological symptoms progression, previous head trauma, family history.',
        'Bladder cancer': 'Smoking history, occupational chemical exposures, recurrent UTIs.'
    };
    
    return histories[patient.Tumor_Type] || 'Comprehensive medical history review recommended.';
}

// Lab status helper
function getLabStatus(test, value) {
    const ranges = {
        'WBC': { min: 4.0, max: 11.0 },
        'Hemoglobin': { min: 12.0, max: 16.0 },
        'Platelets': { min: 150, max: 450 },
        'CRP': { min: 0, max: 5.0 },
        'ESR': { min: 0, max: 20 },
        'Creatinine': { min: 0.5, max: 1.2 },
        'ALT': { min: 7, max: 56 },
        'AST': { min: 10, max: 40 }
    };
    
    const range = ranges[test];
    if (!range) return 'normal';
    
    if (value < range.min) return 'low';
    if (value > range.max) return 'high';
    return 'normal';
}

// AI Analysis function
function displayAIAnalysis(patient) {
    const analysis = generateAIAnalysis(patient);
    
    document.getElementById('aiAnalysis').innerHTML = `
        <div class="ai-finding">
            <h4><i class="fas fa-search"></i> AI Findings</h4>
            <p>${analysis.findings}</p>
        </div>
        <div class="ai-confidence">
            <h4><i class="fas fa-chart-bar"></i> Confidence Metrics</h4>
            <div class="confidence-metrics">
                <div class="metric">
                    <span class="metric-label">Detection Confidence</span>
                    <div class="confidence-bar">
                        <div class="confidence-fill" style="width: ${analysis.confidence}%"></div>
                    </div>
                    <span class="metric-value">${analysis.confidence}%</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Tumor Characterization</span>
                    <div class="confidence-bar">
                        <div class="confidence-fill" style="width: ${analysis.characterization}%"></div>
                    </div>
                    <span class="metric-value">${analysis.characterization}%</span>
                </div>
            </div>
        </div>
        <div class="ai-recommendation">
            <h4><i class="fas fa-lightbulb"></i> Clinical Recommendations</h4>
            <p>${analysis.recommendations}</p>
        </div>
        <div class="ai-risk">
            <h4><i class="fas fa-exclamation-triangle"></i> Risk Assessment</h4>
            <div class="risk-level ${analysis.riskLevel}">
                <i class="fas fa-${analysis.riskIcon}"></i>
                ${analysis.riskAssessment}
            </div>
        </div>
    `;
}

// Generate AI Analysis based on patient data
function generateAIAnalysis(patient) {
    const tumorType = patient.Tumor_Type.toLowerCase();
    let findings = '';
    let recommendations = '';
    let confidence = 85 + Math.floor(Math.random() * 15); // 85-99%
    let characterization = 80 + Math.floor(Math.random() * 20); // 80-99%
    let riskAssessment = '';
    let riskLevel = 'medium';
    let riskIcon = 'exclamation-circle';

    if (tumorType.includes('breast')) {
        findings = 'AI Detection: Irregular mass with spiculated margins measuring approximately 2.3cm. Suspicious microcalcifications present in cluster formation. Mild architectural distortion noted. BI-RADS 4 assessment.';
        recommendations = 'Recommended: Ultrasound-guided core biopsy for histopathological confirmation. BRCA1/2 genetic testing. Contrast-enhanced MRI for further characterization. Surgical oncology consultation.';
        riskAssessment = 'Moderate suspicion for malignancy. Urgent biopsy recommended.';
        riskLevel = 'high';
        riskIcon = 'exclamation-triangle';
    } else if (tumorType.includes('lung')) {
        findings = 'AI Detection: Solid pulmonary nodule measuring 1.8cm with irregular borders in right upper lobe. Ground-glass opacity component observed. No significant lymphadenopathy.';
        recommendations = 'Recommended: PET-CT for metabolic activity assessment. Bronchoscopy with biopsy. Pulmonary function tests. Thoracic surgery consultation.';
        riskAssessment = 'High suspicion for primary lung malignancy. FDG avidity expected.';
        riskLevel = 'high';
        riskIcon = 'exclamation-triangle';
    } else if (tumorType.includes('pancreatic')) {
        findings = 'AI Detection: Hypodense pancreatic mass measuring 3.2cm in head region with vascular encasement. Common bile duct dilation to 12mm. Pancreatic duct cutoff sign present.';
        recommendations = 'Recommended: EUS with FNA for tissue diagnosis. CA19-9 monitoring. MRCP for ductal anatomy. Surgical oncology evaluation.';
        riskAssessment = 'High probability of pancreatic adenocarcinoma. Vascular involvement concerning.';
        riskLevel = 'high';
        riskIcon = 'exclamation-triangle';
    } else if (tumorType.includes('brain')) {
        findings = 'AI Detection: Enhancing intra-axial mass measuring 4.1cm with surrounding vasogenic edema. Mass effect on lateral ventricle. Heterogeneous enhancement pattern.';
        recommendations = 'Recommended: Neurosurgical evaluation. Steroid therapy for edema control. Advanced MRI sequences (DWI, PWI). Molecular profiling if feasible.';
        riskAssessment = 'High-grade glioma suspected. Urgent neurosurgical consultation needed.';
        riskLevel = 'high';
        riskIcon = 'exclamation-triangle';
    } else {
        findings = 'AI Detection: Abnormal tissue morphology with heterogeneous contrast enhancement. Irregular margins with infiltrative pattern. Further characterization required for definitive diagnosis.';
        recommendations = 'Recommended: Multi-parametric imaging assessment. Image-guided biopsy for histopathology. Specialist oncology consultation. Molecular marker analysis.';
        riskAssessment = 'Indeterminate findings. Tissue diagnosis essential.';
        riskLevel = 'medium';
        riskIcon = 'question-circle';
    }

    return { 
        findings, 
        recommendations, 
        confidence, 
        characterization,
        riskAssessment,
        riskLevel,
        riskIcon
    };
}

// Show patient MRI from GitHub
function showPatientMRI() {
    if (!currentPatient) {
        showNotification('Please search for a patient first.', 'warning');
        return;
    }

    const mriContainer = document.getElementById('mriImage');
    
    // Show loading
    showLoading(true);
    mriContainer.innerHTML = `
        <div class="mri-loading">
            <div class="loading-brain">
                <i class="fas fa-brain"></i>
            </div>
            <p>Loading Enhanced Tumor MRI...</p>
            <div class="loading-dots">
                <span></span>
                <span></span>
                <span></span>
            </div>
        </div>
    `;

    // Get random MRI from your GitHub images
    const randomIndex = Math.floor(Math.random() * githubMRIImages.length);
    const randomImage = githubMRIImages[randomIndex];
    
    // Create image element
    const img = new Image();
    img.src = randomImage;
    img.alt = `Enhanced Tumor MRI for ${currentPatient.PatientID}`;
    img.className = 'mri-image';
    
    img.onload = function() {
        mriContainer.innerHTML = '';
        
        // Create image container with controls
        const imageContainer = document.createElement('div');
        imageContainer.className = 'mri-image-container';
        
        // Add image
        imageContainer.appendChild(img);
        
        // Add image info and controls
        const imageInfo = document.createElement('div');
        imageInfo.className = 'mri-image-info';
        imageInfo.innerHTML = `
            <div class="image-meta">
                <h4>Enhanced Tumor MRI</h4>
                <p>Patient: ${currentPatient.PatientID} | ${currentPatient.Tumor_Type}</p>
                <div class="image-controls">
                    <button class="btn btn-outline" onclick="zoomImage(this)">
                        <i class="fas fa-search-plus"></i>
                        Zoom
                    </button>
                    <button class="btn btn-outline" onclick="downloadImage('${randomImage}')">
                        <i class="fas fa-download"></i>
                        Download
                    </button>
                </div>
            </div>
        `;
        
        imageContainer.appendChild(imageInfo);
        mriContainer.appendChild(imageContainer);
        
        showLoading(false);
        showNotification('MRI loaded successfully! AI analysis completed.', 'success');
    };
    
    img.onerror = function() {
        mriContainer.innerHTML = `
            <div class="mri-error">
                <i class="fas fa-exclamation-triangle"></i>
                <h4>Image Load Error</h4>
                <p>Could not load MRI from GitHub repository.</p>
                <p class="error-help">Please ensure:</p>
                <ul>
                    <li>GitHub repository is public</li>
                    <li>Image URLs are correctly formatted</li>
                    <li>Images are in JPG/PNG format</li>
                </ul>
                <button class="btn btn-primary" onclick="uploadMRIImage()">
                    <i class="fas fa-upload"></i>
                    Upload Local MRI
                </button>
            </div>
        `;
        showLoading(false);
        showNotification('Failed to load MRI image. Check GitHub configuration.', 'error');
    };
}

// Upload MRI Image
function uploadMRIImage() {
    if (!currentPatient) {
        showNotification('Please search for a patient first.', 'warning');
        return;
    }

    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*,.dcm,.jpg,.jpeg,.png,.dicom';
    
    input.onchange = function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const mriContainer = document.getElementById('mriImage');
                const img = new Image();
                img.src = e.target.result;
                img.alt = `Uploaded MRI for ${currentPatient.PatientID}`;
                img.className = 'mri-image';
                
                mriContainer.innerHTML = '';
                
                const imageContainer = document.createElement('div');
                imageContainer.className = 'mri-image-container';
                imageContainer.appendChild(img);
                
                const imageInfo = document.createElement('div');
                imageInfo.className = 'mri-image-info';
                imageInfo.innerHTML = `
                    <div class="image-meta">
                        <h4>Uploaded MRI Scan</h4>
                        <p>Patient: ${currentPatient.PatientID} | File: ${file.name}</p>
                        <div class="upload-success">
                            <i class="fas fa-check-circle"></i>
                            Successfully uploaded
                        </div>
                    </div>
                `;
                
                imageContainer.appendChild(imageInfo);
                mriContainer.appendChild(imageContainer);
                
                showNotification(`MRI uploaded successfully for ${currentPatient.PatientID}`, 'success');
                
                // Regenerate AI analysis for new image
                setTimeout(() => {
                    displayAIAnalysis(currentPatient);
                }, 500);
            };
            reader.readAsDataURL(file);
        }
    };
    
    input.click();
}

// Generate Prescription
function generatePrescription() {
    if (!currentPatient) {
        showNotification('Please search for a patient first.', 'warning');
        return;
    }

    showLoading(true);

    // Simulate prescription generation
    setTimeout(() => {
        const prescription = `
            <div class="prescription-header">
                <h4><i class="fas fa-pills"></i> Treatment Plan & Prescription</h4>
                <p>Generated: ${new Date().toLocaleDateString()} | Valid until: ${getFutureDate(30)}</p>
            </div>
            <div class="prescription-details">
                <div class="prescription-item">
                    <strong>Current Treatment Protocol:</strong> 
                    <span class="treatment-protocol">${currentPatient.Treatment}</span>
                </div>
                <div class="prescription-item">
                    <strong>Recommended Medications:</strong> 
                    <div class="medication-list">${getMedications(currentPatient.Tumor_Type)}</div>
                </div>
                <div class="prescription-item">
                    <strong>Dosage & Administration:</strong> 
                    <div class="dosage-info">${getDosageInfo(currentPatient.Tumor_Type)}</div>
                </div>
                <div class="prescription-item">
                    <strong>Follow-up Schedule:</strong> 
                    <div class="followup-schedule">${getFollowUpSchedule(currentPatient.Outcome)}</div>
                </div>
                <div class="prescription-item">
                    <strong>Monitoring Parameters:</strong> 
                    <div class="monitoring-params">${getMonitoringParameters(currentPatient.Tumor_Type)}</div>
                </div>
                <div class="prescription-item">
                    <strong>Special Instructions & Precautions:</strong> 
                    <div class="special-instructions">${getSpecialInstructions(currentPatient.Tumor_Type)}</div>
                </div>
            </div>
            <div class="doctor-signature">
                <div class="signature-line"></div>
                <p><strong>Dr. Alex Chen, MD</strong><br>
                Oncology Specialist<br>
                License: MED123456<br>
                NeuroVision AI Medical Center</p>
            </div>
        `;

        document.getElementById('prescriptionOutput').innerHTML = prescription;
        showLoading(false);
        showNotification('Prescription generated successfully!', 'success');
    }, 1500);
}

// Helper functions for prescription
function getMedications(tumorType) {
    const meds = {
        'breast': `
            <div class="medication">
                <span class="med-name">Tamoxifen Citrate</span>
                <span class="med-dosage">20mg tablet</span>
                <span class="med-frequency">Once daily</span>
            </div>
            <div class="medication">
                <span class="med-name">Letrozole</span>
                <span class="med-dosage">2.5mg tablet</span>
                <span class="med-frequency">Once daily</span>
            </div>
            <div class="medication">
                <span class="med-name">Calcium + Vitamin D3</span>
                <span class="med-dosage">500mg/400IU</span>
                <span class="med-frequency">Once daily</span>
            </div>
        `,
        'lung': `
            <div class="medication">
                <span class="med-name">Osimertinib</span>
                <span class="med-dosage">80mg tablet</span>
                <span class="med-frequency">Once daily</span>
            </div>
            <div class="medication">
                <span class="med-name">Carboplatin</span>
                <span class="med-dosage">AUC 5</span>
                <span class="med-frequency">IV every 3 weeks</span>
            </div>
            <div class="medication">
                <span class="med-name">Pemetrexed</span>
                <span class="med-dosage">500mg/m²</span>
                <span class="med-frequency">IV every 3 weeks</span>
            </div>
        `,
        'pancreatic': `
            <div class="medication">
                <span class="med-name">Gemcitabine</span>
                <span class="med-dosage">1000mg/m²</span>
                <span class="med-frequency">IV weekly for 3 weeks</span>
            </div>
            <div class="medication">
                <span class="med-name">Nab-paclitaxel</span>
                <span class="med-dosage">125mg/m²</span>
                <span class="med-frequency">IV weekly for 3 weeks</span>
            </div>
            <div class="medication">
                <span class="med-name">Pancreatic Enzymes</span>
                <span class="med-dosage">25,000 units</span>
                <span class="med-frequency">With meals</span>
            </div>
        `,
        'brain': `
            <div class="medication">
                <span class="med-name">Temozolomide</span>
                <span class="med-dosage">150mg/m²</span>
                <span class="med-frequency">Daily for 5 days every 28 days</span>
            </div>
            <div class="medication">
                <span class="med-name">Dexamethasone</span>
                <span class="med-dosage">4mg tablet</span>
                <span class="med-frequency">Twice daily, taper as tolerated</span>
            </div>
            <div class="medication">
                <span class="med-name">Levetiracetam</span>
                <span class="med-dosage">500mg tablet</span>
                                <span class="med-frequency">Twice daily for seizure prophylaxis</span>
            </div>
        `
    };
    
    return meds[tumorType] || `
        <div class="medication">
            <span class="med-name">Treatment based on molecular profiling</span>
            <span class="med-dosage">Individualized regimen</span>
            <span class="med-frequency">As per oncology consultation</span>
        </div>
    `;
}

function getDosageInfo(tumorType) {
    const dosage = {
        'breast': 'Take oral medications with food. Continue treatment for minimum 5 years unless otherwise specified. Regular monitoring of bone density required.',
        'lung': 'Administer IV medications under supervision. Pre-medicate with antiemetics. Monitor for hematological toxicity and renal function.',
        'pancreatic': 'IV infusion over 30 minutes. Monitor for myelosuppression and neuropathy. Dose adjustments based on toxicity.',
        'brain': 'Take temozolomide on empty stomach. Dexamethasone to be tapered gradually. Monitor for infection and metabolic changes.'
    };
    return dosage[tumorType] || 'Individualized dosing based on patient factors and treatment response.';
}

function getFollowUpSchedule(outcome) {
    const schedules = {
        'Recovered': '3-month clinical follow-up with imaging. Annual surveillance thereafter.',
        'Stable': 'Monthly clinical assessment. 3-month imaging studies. Laboratory monitoring every 2 weeks.',
        'Progressive': '2-week clinical review. Consider treatment modification. Imaging every 6-8 weeks.',
        'Deceased': 'Family counseling and bereavement support. Medical record completion.'
    };
    return schedules[outcome] || 'Individualized follow-up based on treatment phase and response.';
}

function getMonitoringParameters(tumorType) {
    const params = {
        'breast': 'CBC, LFTs, renal function, tumor markers (CA 15-3), bone density, cardiac function',
        'lung': 'CBC, LFTs, renal function, pulmonary function tests, imaging response, oxygen saturation',
        'pancreatic': 'CBC, LFTs, amylase/lipase, CA19-9, nutritional status, glucose monitoring',
        'brain': 'CBC, LFTs, renal function, neurological assessment, imaging, seizure monitoring'
    };
    return params[tumorType] || 'CBC, comprehensive metabolic panel, disease-specific markers, imaging studies';
}

function getSpecialInstructions(tumorType) {
    const instructions = {
        'breast': 'Report any new lumps, bone pain, or respiratory symptoms immediately. Maintain regular exercise and calcium-rich diet.',
        'lung': 'Immediately report worsening cough, shortness of breath, or chest pain. Smoking cessation essential.',
        'pancreatic': 'Report abdominal pain, jaundice, or weight loss. Nutritional support and enzyme replacement as needed.',
        'brain': 'Report any new neurological symptoms, seizures, or headaches. Avoid driving if seizures occur.'
    };
    return instructions[tumorType] || 'Report any new or worsening symptoms immediately. Maintain hydration and nutrition. Attend all scheduled appointments.';
}

function getFutureDate(days) {
    const date = new Date();
    date.setDate(date.getDate() + days);
    return date.toLocaleDateString();
}

// Quick Actions Functions
function showAllPatients() {
    const patientCount = allPatients.length;
    const patientList = allPatients.slice(0, 10).map(p => p.PatientID).join(', ');
    
    showNotification(`Total patients in system: ${patientCount}\nRecent patients: ${patientList}...`, 'info');
}

function uploadImage() {
    if (currentPatient) {
        uploadMRIImage();
    } else {
        showNotification('Please search for a patient first to upload MRI images.', 'warning');
    }
}

function generateReport() {
    if (currentPatient) {
        generatePrescription();
        showNotification('📊 Comprehensive medical report generated! Scroll down to view treatment plan.', 'success');
    } else {
        showNotification('Please search for a patient first to generate reports.', 'warning');
    }
}

function showStatistics() {
    const stats = {
        totalPatients: allPatients.length,
        recovered: allPatients.filter(p => p.Outcome.includes('Recovered')).length,
        stable: allPatients.filter(p => p.Outcome.includes('Stable')).length,
        progressive: allPatients.filter(p => p.Outcome.includes('Progressive')).length
    };
    
    showNotification(
        `📈 System Statistics:\n\n` +
        `Total Patients: ${stats.totalPatients}\n` +
        `Recovered: ${stats.recovered}\n` +
        `Stable: ${stats.stable}\n` +
        `Progressive: ${stats.progressive}\n` +
        `Success Rate: ${Math.round((stats.recovered / stats.totalPatients) * 100)}%`,
        'info'
    );
}

// Image controls
function zoomImage(button) {
    const img = button.closest('.mri-image-container').querySelector('.mri-image');
    img.classList.toggle('zoomed');
    button.innerHTML = img.classList.contains('zoomed') ? 
        '<i class="fas fa-search-minus"></i> Zoom Out' : 
        '<i class="fas fa-search-plus"></i> Zoom';
}

function downloadImage(imageUrl) {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `MRI_${currentPatient.PatientID}_${Date.now()}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showNotification('MRI image download started!', 'success');
}

// Utility Functions
function showLoading(show) {
    const overlay = document.getElementById('loadingOverlay');
    if (show) {
        overlay.style.display = 'flex';
        document.body.style.overflow = 'hidden';
    } else {
        overlay.style.display = 'none';
        document.body.style.overflow = 'auto';
    }
}

function showNotification(message, type = 'info') {
    // Remove existing notification
    const existingNotification = document.querySelector('.notification');
    if (existingNotification) {
        existingNotification.remove();
    }

    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    const icons = {
        success: 'fas fa-check-circle',
        error: 'fas fa-exclamation-circle',
        warning: 'fas fa-exclamation-triangle',
        info: 'fas fa-info-circle'
    };
    
    notification.innerHTML = `
        <div class="notification-content">
            <i class="${icons[type]}"></i>
            <span>${message}</span>
        </div>
        <button class="notification-close" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

// Handle Enter key in search
document.getElementById('patientSearch').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        searchPatient();
    }
});

// Add real-time search suggestions
document.getElementById('patientSearch').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toUpperCase();
    if (searchTerm.length > 2) {
        showSearchSuggestions(searchTerm);
    }
});

function showSearchSuggestions(searchTerm) {
    const suggestions = allPatients
        .filter(patient => patient.PatientID.includes(searchTerm))
        .slice(0, 5)
        .map(patient => patient.PatientID);
    
    // You can implement a dropdown suggestion UI here
    if (suggestions.length > 0) {
        console.log('Suggestions:', suggestions);
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    loadPatientData();
    
    // Add some interactive effects
    addInteractiveEffects();
    
    console.log('NeuroVision AI Dashboard initialized successfully! 🧠');
});

function addInteractiveEffects() {
    // Add hover effects to cards
    const cards = document.querySelectorAll('.dashboard-card, .kpi-card, .action-card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.boxShadow = '0 15px 35px rgba(0,0,0,0.15)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = '0 5px 20px rgba(0,0,0,0.1)';
        });
    });
}

// Add CSS for notifications and additional styles
const additionalStyles = `
    .notification {
        position: fixed;
        top: 100px;
        right: 20px;
        background: white;
        padding: 1rem 1.5rem;
        border-radius: 12px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        border-left: 4px solid var(--teal);
        z-index: 10000;
        max-width: 400px;
        animation: slideInRight 0.3s ease;
    }
    
    .notification-success {
        border-left-color: var(--green);
    }
    
    .notification-error {
        border-left-color: var(--red);
    }
    
    .notification-warning {
        border-left-color: var(--amber);
    }
    
    .notification-info {
        border-left-color: var(--teal);
    }
    
    .notification-content {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }
    
    .notification-close {
        background: none;
        border: none;
        color: var(--text-light);
        cursor: pointer;
        padding: 0.25rem;
        margin-left: 1rem;
    }
    
    .mri-image.zoomed {
        transform: scale(1.5);
        cursor: zoom-out;
    }
    
    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        padding: 0.5rem 1rem;
        border-radius: 20px;
        font-weight: 600;
        font-size: 0.85rem;
    }
    
    .outcome-recovered {
        background: rgba(46, 204, 113, 0.1);
        color: var(--green);
        border: 1px solid var(--green);
    }
    
    .outcome-stable {
        background: rgba(255, 193, 7, 0.1);
        color: var(--amber);
        border: 1px solid var(--amber);
    }
    
    .outcome-progressive {
        background: rgba(231, 76, 60, 0.1);
        color: var(--red);
        border: 1px solid var(--red);
    }
    
    .outcome-deceased {
        background: rgba(160, 174, 192, 0.1);
        color: var(--text-light);
        border: 1px solid var(--text-light);
    }
    
    .lab-value.low { color: var(--amber); font-weight: 600; }
    .lab-value.high { color: var(--red); font-weight: 600; }
    .lab-value.normal { color: var(--green); font-weight: 600; }
    
    .treatment-badge {
        background: var(--gradient-primary);
        color: white;
        padding: 0.5rem 1rem;
        border-radius: 8px;
        font-weight: 600;
        font-size: 0.9rem;
    }
    
    .icd-code {
        background: var(--stone);
        padding: 0.25rem 0.5rem;
        border-radius: 4px;
        font-family: monospace;
        font-weight: 600;
    }
    
    @keyframes slideInRight {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    .mri-loading {
        text-align: center;
        padding: 3rem;
    }
    
    .loading-dots span {
        animation: bounce 1.4s infinite ease-in-out both;
        background: var(--teal);
        border-radius: 50%;
        display: inline-block;
        height: 10px;
        width: 10px;
        margin: 0 2px;
    }
    
    .loading-dots span:nth-child(1) { animation-delay: -0.32s; }
    .loading-dots span:nth-child(2) { animation-delay: -0.16s; }
    
    @keyframes bounce {
        0%, 80%, 100% { transform: scale(0); }
        40% { transform: scale(1); }
    }
`;

// Inject additional styles
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);